<?php
require_once("./PDO/connex.php");
$query = "select image,image_type from usrsprofiles WHERE username = ?";
$stmt = $pdo->prepare( $query );
$stmt->bindParam(1, $_GET['id']); 
$stmt->execute();
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	header("Content-type: ".$row['image_type']);
	print $row['image'];
	exit;
?>
