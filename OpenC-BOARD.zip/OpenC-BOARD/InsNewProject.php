
<?php
//SESSION_START();

$pname=trim($_POST["pname"]);
$pname=strip_tags($pname);
$pnumber=trim($_POST["pnumber"]);
$pnumber=strip_tags($pnumber);
$pdecrption=trim($_POST["pdescr"]);
$pdecrption=strip_tags($pdecrption);

 require_once("./PDO/connex.php");


$usrsnme = $_SESSION['user']['username'];
//
$insertproj = "INSERT INTO wbs (lev,L1,L2,L3,L4,L5,L6,nam,des,wbsnumber,activ) VALUES (:lev, :L1, :L2, :L3, :L4, :L5, :L6, :nam, :des, :num, :activ)";
$init0 = "0";
$init1 = "1";
					$pdoexecNP = $pdo->prepare($insertproj);
					$pdoexecNP->execute(array(':lev'=>$init1,':L1'=>$init0,':L2'=>$init0,':L3'=>$init0, ':L4'=>$init0, ':L5'=>$init0, ':L6'=>$init0, ':nam'=>$pname, ':des'=>$pdecrption, ':num'=>$pnumber, 'activ'=>$init1));

// INSERT initial Thread for the new project:
		$n_id = 1; // belongs to 1st wbs-element. mandatory.
 		$ini_topic = $pname . '-related discussion';
		$ini_descr = $pdecrption . ' (initial thread)';
/*		
$ini_topic = htmlentities($nam, ENT_COMPAT | ENT_HTML401, 'ISO-8859-1')  . '-related discussion';
$ini_descr = htmlentities($desc, ENT_COMPAT | ENT_HTML401, 'ISO-8859-1',true) . ' (initial thread)';*/
		$ini_closed = 0;
			

					$insertinitial = "INSERT INTO strg (Pid,topic,dscrption,closed) VALUES (:n_id, :topic, :dscrption, :closed)";

					$pdoexecIni = $pdo->prepare($insertinitial);
					$pdoexecIni->execute(array(':n_id'=>$n_id,':topic'=>$ini_topic,':dscrption'=>$ini_descr,':closed'=>$ini_closed));



header('location:newWBSelement.php');

 exit();
?>