
<?php
//newPW.php?USrid=161&&SI=1393969117
 
$UsrID4send=$_POST["UsrID4PWlink"];

$UsrToken4send=$_POST["PWtoken4link"];

$UsrsEmail=$_POST["usrsemail"];
/*
$myServerURL = $_SERVER['REQUEST_URI'];
echo $_SERVER['REQUEST_URI'];*/
//	
$path=$_SERVER['SERVER_NAME']; // z.B.: projectboard.azurewebsites.net


echo '<br><br>';
echo'user s id = '.$UsrID4send;
echo'<br><br>';
echo'ResetToken = '.$UsrToken4send;
echo'<br><br>';
echo'users email where to send via sendgrid the reset-pw-link: '.$UsrsEmail;
echo'
following url was created for reset the password:<br>
<a href="http://'.$path.'/login/newPW.php?USrid='.$UsrID4send.'&&SI='.$UsrToken4send.'">http://'.$path.'/login/newPW.php?USrid='.$UsrID4send.'&&SI='.$UsrToken4send.'</a><br>
click or copy the link into the address-bar of your browser for resetting your password.<br> ';


//header('location:usrAdminPanel_all5.php');

 exit();
?>