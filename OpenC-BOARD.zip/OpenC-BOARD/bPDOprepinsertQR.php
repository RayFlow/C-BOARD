<?php
	SESSION_START();
 	$usar= ($_SESSION['user']['username']); 
	$qr = trim($_POST["qr"]);
	$qr =strip_tags($qr, '<b><u><i></b></u></i>');
 	require_once("./PDO/connex.php");
$b=$pdo->prepare('INSERT into cflags(username,qr)VALUES(:usar,:qr)');
$b->bindParam(":usar",$usar);
$b->bindParam(":qr",$qr);
$b->execute();
?>
