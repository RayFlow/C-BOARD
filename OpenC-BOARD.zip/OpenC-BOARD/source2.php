<?php
require_once("./PDO/connex.php");
 
$query = "select image2,image_type2 from usrsprofiles WHERE username = ?";
$stmt = $pdo->prepare( $query );
 
$stmt->bindParam(1, $_GET['id']);  
$stmt->execute();
 
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	 
	 header("Content-type: ".$row['image_type2']);

	//display the image data
	print $row['image2'];
	exit;


?>
