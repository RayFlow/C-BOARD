<?php


			$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";   
			$targetfolder = substr($actual_link, 0, -17); // login/welcome.php = 17
			$overview = "overview.php"; // go to the c-board's overview.php page
			$locationlink = $targetfolder.$overview ;
			
			
		echo'	<br>$actual_link = '.		$actual_link ;//"http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";   
		echo'	<br>$targetfolder = '. $targetfolder  ;// substr($actual_link, 0, -17); // login/welcome.php = 17
		echo'	<br>$overview ='. 	$overview  ;//"overview.php"; // go to the c-board's overview.php page
		echo'	<br>$locationlink = '. 	$locationlink ;// $targetfolder.$overview ;
		
		echo'<h2>ERGEBNIS:</h2>';
		echo'
$actual_link = http://c-board.de/OpenC-BOARD/urltest.php<br>
$targetfolder = http://c-board.de/OpenC-<br><br>';

echo '<p><b>17 Zeichen von der aktuellen url abgezogen ergeben den targetfolder </b></p>';
		