<?php
session_start();
//

// for usage wit mySQl-database on your LAMP-stack. (do not use the same example)
$dbconfig['host'] = 'localhost'; // check host, often localhost, but not always (e.g. at the free-hoster hostinger.de: mysql.hostinger.de)
$dbconfig['port'] = '3306'; // check port
$dbconfig['user'] = 'databaseusername'; // set a user with your mySQL-database set-up at your provider & use the same db-access-name
$dbconfig['base'] = 'databasename';		// create a mySQL-database at your provider & use the same db-name
$dbconfig['pass'] = 'databasepassword';		// use the same password 
$dbconfig['char'] = 'utf8';

try {
    $pdo = new PDO('mysql:host='.$dbconfig['host'].';port='.$dbconfig['port'].';dbname='.$dbconfig['base'].';charset='.$dbconfig['char'].';', $dbconfig['user'], $dbconfig['pass']);
}
catch(PDOException $e) {
    exit('Unable to connect Database.');
}


?>