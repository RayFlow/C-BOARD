<?php
// for registration-mails from the system as well as for email-sending-functionalities (wbs-related CFLX-mails)
// you need an account of an E-Mail-Provider/ E-Mail_service-Provider.
// For the C-BOARD you usually can benefit from free offers, like:
// "10,000 emails free for every month" (mailgun.com, Feb.23.2016)
// "6,000 free emails a month" (mailjet.com Feb.23 2016)
//  "9,000 free/ Month" (sendinblue.com Feb.23 2016)
// ... & many, many others. 
// "Free 12k - 12k/mo" (sendgrid.com Feb.23 2016)

	$mailersName = "EmailServiceProviderUsername"; // the user-name used for your email-service-provider
	$mailersPass =  "EmailServiceProviderPassword"; // the password used for your email-service-provider
	$mailersHost =  'EmailServiceProviderHost'; // the (smtp) host of your email-service-provider(e.g.: smtp.sendgrid.net)
	$mailersEncryptionType = 'tls';
	$mailersPort = 587; // the port of your email-service-provider
