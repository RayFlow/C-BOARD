<?php
require_once("./PDO/connex.php");

     
	//$usrsname= htmlentities($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8');
	// keine html-codes für sonderzeichen hier! wird nun alles korrekt in utf-8 auf db abgelegt - und auch damit korrekt vergliechen. 
	// eine Ergänzung wäre nur für die ausgabe im Brwser ggfls. nötig. 
	$usrsname= ($_SESSION['user']['username']);
//select the image
$query = "select image2,image_type2 from usrsprofiles WHERE username = ?";
$stmt = $pdo->prepare( $query );
 
$stmt->bindParam(1, $usrsname); 
$stmt->execute();

	//if found
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	
	
	 header("Content-type: ".$row['image_type2']);

	//display the image data
	print $row['image2'];
	exit;

//}
?>
