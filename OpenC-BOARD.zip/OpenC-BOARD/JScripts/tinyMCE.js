
				tinyMCE.init({
					
			    // 	entity_encoding : "raw"


		
        			theme : "modern",
        			mode : "specific_textareas",
        			editor_selector : "mssgtxtarea", 
        			menubar : false,
        			plugins: [
        						"colorpicker emoticons textcolor image"
        						],
    	 			toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | forecolor backcolor |   emoticons"

					});
