
function CheckJarrayqr () {

alert('ok, bin drin!');}
	/*while( api-- ) {
    if(jarray[api].ap === qrEntryString ) 
return;
		}
	if(api === -1)
		 { StartDialog(qrEntryString);}
}
*/