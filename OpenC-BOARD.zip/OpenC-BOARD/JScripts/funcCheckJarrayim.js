
function CheckJarrayim () {
	while( api-- ) {
    if(jarray[api].ap === imEntryString ) 
return;
		}
	if(api === -1)
		 { StartDialog(imEntryString);}
}
