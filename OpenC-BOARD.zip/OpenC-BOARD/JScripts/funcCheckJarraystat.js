
function CheckJarraystat () {
	while( stati-- ) {
    if(jarray[stati].stat === statEntryString ) 
return;
		}
	if(stati === -1)
		 { StartDialog(statEntryString);}
}
