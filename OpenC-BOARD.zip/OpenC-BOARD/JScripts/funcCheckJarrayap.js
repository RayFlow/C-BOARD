
function CheckJarrayap () {
	while( api-- ) {
    if(jarray[api].ap === apEntryString ) 
return;
		}
	if(api === -1)
		 { StartDialog(apEntryString);}
}
