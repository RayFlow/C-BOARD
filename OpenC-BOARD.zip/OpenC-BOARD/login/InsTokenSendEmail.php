
<?php
//SESSION_START();
//
// 1.) user kommt über link "forgot my passwort / username-password-combination"  d.h.: keine weiteren user-informationen sind bekannt
// 2.) user trägt seinen namen oder seine emailadresse in eingabefeld ein
// 3.) 3.) fällt weg. wird über browser realisiert.    if(!empty($_POST)) // nur, wenn das Eingabefeld nicht leer steht 																					-> 1. if-else-anweisung
// 4.) eintrag wird auf vorhandensein in db-table reg geprüft (if ( $nameemail === $array['username'] || $nameemail === $array['email'] ) {  echo "nameemail var ist in db vorhande und gesetzt ";}) 					-> 2. if-else-anweisung
// 5.) if eintrag vorhanden -> lese username 

$usernameemail=$_POST["usernameemail"];
// $PWersatz ="PWreset00";

 include_once('../PDO/connex.php');

// zu 4.b) check if avaiable START
   $query = "SELECT id,username,email FROM reg WHERE (username = :username || email = :email)";
        
        // This contains the definitions for any special tokens that we place in
        // our SQL query.  In this case, we are defining a value for the token
        // :username.  It is possible to insert $_POST['username'] directly into
        // your $query string; however doing so is very insecure and opens your
        // code up to SQL injection exploits.  Using tokens prevents this.
        // For more information on SQL injections, see Wikipedia:
        // http://en.wikipedia.org/wiki/SQL_Injection
        $query_params = array(
            ':username' => $usernameemail,  ':email' => $usernameemail
        );
        
        try
        {
            // These two statements run the query against your database table.
            $stmt = $pdo->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            // Note: On a production website, you should not output $ex->getMessage().
            // It may provide an attacker with helpful information about your code. 
            die("Failed to run query: " . $ex->getMessage());
        }
        
        // The fetch() method returns an array representing the "next" row from
        // the selected results, or false if there are no more rows to fetch.
        $namemailArray = $stmt->fetch();
        
        // If a row was returned, then we know a matching username or email was found in
        // the database and we can start creating and sending the email with using the data from the $namemailArray.
        if($namemailArray)
        {
// ****************************************************************************************************************************************************************************
 // START UPDATE reg mit Token sowie erstelle und sende "Usr-ID + Token link email" an den user. anschl. redirekt zum login.php
 // a) ziehe user-ID, username und email aus dem array in einzelnen Variablen
 // b) query zum UPDATE zwecks eintragung des Token in die db
 // c) erstelle customized email
 // d) sende customized email
 
 // zu a)				
		$UsersID=$namemailArray['id'] ; 
		$UsersName=$namemailArray['username'] ; 
		$UsersEmail=$namemailArray['email'] ; 
 		$Token = mt_rand(); // zum Eintrag in Datenbank reg sowie zum hinzufügen in den new-pw-link der email
 // zu b)
 		$Update4Token = 'UPDATE reg set SecToken=:PrimDings where id=:id';
		$prep4TokStatement = $pdo->prepare($Update4Token);
		$prep4TokStatement->execute(array(':PrimDings' => $Token , ':id' => $UsersID));
 // zu c)+d)
 // just use require_once 99.9% of the time.
 
// include_once('../PDO/mailerConnexStrings.php');
//require_once'../PDO/mailerConnexStrings.php'; // wird nun direct im sgPHPmailer reqired_once ...
	//	$SendGridUsr = "CFLXmaster";
	//	$SendGridPW = "MoH@Waldburg666";

		$subject = "You were requesting a new password for your cboard-account";
require_once '../sgPHPmailer_newPW.php';

 
 						
 		// start				
 					//	header("Location: login.php");
            	//	die("Redirecting to login.php");
// ****************************************************************************************************************************************************************************
        }
// else (= kein Passender Eintrag gefunden), we pop up an alert and redirect to the user-login to prevent bruteforcing
      	else { 
      		$message = "Your entry does not match to any user or email in our member-list. Please re-try or contact your cboard-admin (might be your project manager / PMO / IT-Department or somebody else with admin-rights to the cboard)  ";
				echo "<script type='text/javascript'>alert('$message');</script>";
       	   // This redirects the user back to the login page after they register
        	//	header("Location: login.php");
        
        // Calling die or exit after performing a redirect using the header function
        // is critical.  The rest of your PHP script will continue to execute and
        // will be sent to the user if you do not die or exit.
        //		die("Redirecting to login.php");
     		}

// 4. ende
		//updating some some data
		//$sqlInsert = 'UPDATE reg set password=:pw , SecToken=:PrimDings where (id=:id AND permission=:perm)'; versuch mit AND. OK, geht so.
	/*	$sqlInsert = 'UPDATE reg set password=:pw , SecToken=:PrimDings where id=:id';
		$preparedStatement = $pdo->prepare($sqlInsert);
		$preparedStatement->execute(array(':pw' => $PWersatz , ':PrimDings' => $USridGenerated , ':id' => $UsrID4reset));
*/

 exit();
?>