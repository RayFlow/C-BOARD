 <?php
 
require_once "../PDO/connex.php";
   
     
    unset($_SESSION['user']);    
    unset($_SESSION['url']);
     
    header("Location: login.php");
    die("Redirecting to: login.php"); 