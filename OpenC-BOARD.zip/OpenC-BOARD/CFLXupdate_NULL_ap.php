<?php
SESSION_START();

	$ForUsr= ($_SESSION['user']['username']); 
	 require_once("./PDO/connex.php");
	$apPosted4del1= ($_POST['delap']); 
	// is html encoded via ajax key:value pairs sent via data: keyvaluepairs,
	// 2do:  html_entity_decode($apPosted4del1);
	$apPosted4del = html_entity_decode($apPosted4del1);
	$apNULL = NULL;
	
		$sqlUpdateAP = 'UPDATE cflags SET ap=NULL WHERE (ap = :ap AND username = :username)';
		$prepAP = $pdo->prepare($sqlUpdateAP);
		$prepAP->execute(array(':ap' => $apPosted4del, ':username' => $ForUsr));

    header("Location: persProfile.php#cflxreturn");
    die("Redirecting to persProfile.php");
  