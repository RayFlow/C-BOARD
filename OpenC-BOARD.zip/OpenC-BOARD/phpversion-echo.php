<?php

echo '<h1>php index-and echo-test</h1>';
echo '<br>';
echo "Current version is PHP " . phpversion();

echo '<hr><hr> ';

phpinfo();


